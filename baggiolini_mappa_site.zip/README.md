# I giorni più tristi della prigionia arresa
## Ferruccio Baggiolini — I percorsi 1941–1945

Mappa interattiva dei percorsi di Ferruccio Baggiolini, alpino del 4° Reggimento, Battaglione Intra.

Libro di Aris Baggiolini.
